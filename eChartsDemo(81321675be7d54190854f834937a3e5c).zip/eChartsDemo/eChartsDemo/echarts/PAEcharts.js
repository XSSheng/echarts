document.write("<script language=javascript src='echarts.js'></script>");
var myChart;

function initEchartView(initParams) {
    if (initParams == null || initParams == 'undefined') {
        myChart = echarts.init(document.getElementById('main'));
    } else {
        myChart = echarts.init(document.getElementById('main'), initParams);
    }
}

function onresize() {
    window.onresize = myChart.resize;
}


// 折线图
function echartsFun1(dataList){
    option = {        
    tooltip: {
    trigger: 'axis'
    },
    legend: {
    data:['邮件营销','联盟广告','视频广告','直接访问','搜索引擎']
    },
    grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
    },
    toolbox: {
    feature: {
    saveAsImage: {}
    }
    },
    xAxis: {
    type: 'category',
    boundaryGap: false,
    data: ['周一','周二','周三','周四','周五','周六','周日']
    },
    yAxis: {
    type: 'value'
    },
    series: [
             {
             name:'邮件营销',
             type:'line',
             stack: '总量',
             data:[120, 132, 101, 134, 90, 230, 210]
             },
             {
             name:'联盟广告',
             type:'line',
             stack: '总量',
             data:[220, 182, 191, 234, 290, 330, 310]
             },
             {
             name:'视频广告',
             type:'line',
             stack: '总量',
             data:[150, 232, 201, 154, 190, 330, 410]
             },
             {
             name:'直接访问',
             type:'line',
             stack: '总量',
             data:[320, 332, 301, 334, 390, 330, 320]
             },
             {
             name:'搜索引擎',
             type:'line',
             stack: '总量',
             data:[820, 932, 901, 934, 1290, 1330, 1320]
             }
             ]
    };
    myChart.setOption(option);
}

// 柱状图
function echartsFun2(dataList){
    option = {
        tooltip : {
        trigger: 'axis',
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
    legend: {
    data:['直接访问','邮件营销','联盟广告','视频广告','搜索引擎','百度','谷歌','必应','其他']
    },
    grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
    },
        xAxis : [
                 {
                 type : 'category',
                 data : ['周一','周二','周三','周四','周五','周六','周日']
                 }
                 ],
        yAxis : [
                 {
                 type : 'value'
                 }
                 ],
        series : [
                  {
                  name:'直接访问',
                  type:'bar',
                  data:[320, 332, 301, 334, 390, 330, 320]
                  },
                  {
                  name:'邮件营销',
                  type:'bar',
                  stack: '广告',
                  data:[120, 132, 101, 134, 90, 230, 210]
                  },
                  {
                  name:'联盟广告',
                  type:'bar',
                  stack: '广告',
                  data:[220, 182, 191, 234, 290, 330, 310]
                  },
                  {
                  name:'视频广告',
                  type:'bar',
                  stack: '广告',
                  data:[150, 232, 201, 154, 190, 330, 410]
                  },
                  {
                  name:'搜索引擎',
                  type:'bar',
                  data:[862, 1018, 964, 1026, 1679, 1600, 1570],
                  markLine : {
                  lineStyle: {
                  normal: {
                  type: 'dashed'
                  }
                  },
                  data : [
                          [{type : 'min'}, {type : 'max'}]
                          ]
                  }
                  },
                  {
                  name:'百度',
                  type:'bar',
                  barWidth : 5,
                  stack: '搜索引擎',
                  data:[620, 732, 701, 734, 1090, 1130, 1120]
                  },
                  {
                  name:'谷歌',
                  type:'bar',
                  stack: '搜索引擎',
                  data:[120, 132, 101, 134, 290, 230, 220]
                  },
                  {
                  name:'必应',
                  type:'bar',
                  stack: '搜索引擎',
                  data:[60, 72, 71, 74, 190, 130, 110]
                  },
                  {
                  name:'其他',
                  type:'bar',
                  stack: '搜索引擎',
                  data:[62, 82, 91, 84, 109, 110, 120]
                  }
                  ]
    };

    myChart.setOption(option);
}

// 折线图
function echartsFun3(dataList){
    option = {
    animation: false,
    xAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    yAxis: {
    type: 'value'
    },
    series: [{
             data: [820, 932, 901, 934, 1290, 1330, 1320],
             type: 'line'
             }]
    };
    myChart.setOption(option);
}

// 饼图
function echartsFun4(dataList){
    option = {
        title : {
        text: '某站点用户访问来源',
        subtext: '纯属虚构',
        x:'center'
        },
        tooltip : {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
    legend: {
    orient: 'vertical',
    left: 'left',
    data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
    },
        series : [
                  {
                  name: '访问来源',
                  type: 'pie',
                  radius : '55%',
                  center: ['50%', '60%'],
                  data:[
                        {value:335, name:'直接访问'},
                        {value:310, name:'邮件营销'},
                        {value:234, name:'联盟广告'},
                        {value:135, name:'视频广告'},
                        {value:1548, name:'搜索引擎'}
                        ],
                  itemStyle: {
                  emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                  }
                  }
                  }
                  ]
    };

    myChart.setOption(option);
}

// s散点图
function echartsFun5(dataList){
    option = {
    xAxis: {},
    yAxis: {},
    series: [{
             symbolSize: 20,
             data: [
                    [10.0, 8.04],
                    [8.0, 6.95],
                    [13.0, 7.58],
                    [9.0, 8.81],
                    [11.0, 8.33],
                    [14.0, 9.96],
                    [6.0, 7.24],
                    [4.0, 4.26],
                    [12.0, 10.84],
                    [7.0, 4.82],
                    [5.0, 5.68]
                    ],
             type: 'scatter'
             }]
    };

    myChart.setOption(option);
}

// 折线图
function echartsFun6(dataList){
    option = {
    animation: false,
    xAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    yAxis: {
    type: 'value'
    },
    series: [{
             data: [820, 932, 901, 934, 1290, 1330, 1320],
             type: 'line'
             }]
    };
    myChart.setOption(option);
}

// 折线图
function echartsFun7(dataList){
    option = {
    animation: false,
    xAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    yAxis: {
    type: 'value'
    },
    series: [{
             data: [820, 932, 901, 934, 1290, 1330, 1320],
             type: 'line'
             }]
    };
    myChart.setOption(option);
}
