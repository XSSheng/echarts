//
//  PAEchartsView.h
//  echarts_test
//
//  Created by 徐胜(平安城科) on 2019/7/16.
//  Copyright © 2019 徐胜(平安城科). All rights reserved.
//

/** 实例  https://echarts.baidu.com/examples/ */
/** 样式配置选项  https://echarts.baidu.com/option.html */

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PAEchartsView : WKWebView
@property (nonatomic,strong) NSString *callJs;
@property (nonatomic, copy) dispatch_block_t finishComplete;
+ (NSString *)getJSONString:(id)obj;
+ (PAEchartsView *)newWithFrame:(CGRect)frame;
@end


NS_ASSUME_NONNULL_END
