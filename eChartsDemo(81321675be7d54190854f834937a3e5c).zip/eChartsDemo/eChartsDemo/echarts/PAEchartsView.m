//
//  PAEchartsView.m
//  echarts_test
//
//  Created by 徐胜(平安城科) on 2019/7/16.
//  Copyright © 2019 徐胜(平安城科). All rights reserved.
//

#import "PAEchartsView.h"
@interface PAEchartsView ()<WKScriptMessageHandler,WKNavigationDelegate>
@property (nonatomic,copy)dispatch_block_t optionHandle;
@property (nonatomic, assign) BOOL finishRender;
@property (nonatomic, strong) NSMutableURLRequest *eReauest;

@end

@implementation PAEchartsView

+ (PAEchartsView *)newWithFrame:(CGRect)frame {
    WKWebViewConfiguration *webConfig = [WKWebViewConfiguration new];
    WKUserContentController *userController = [WKUserContentController new];
    webConfig.userContentController = userController;        
    PAEchartsView *webView = [[PAEchartsView alloc] initWithFrame:frame configuration:webConfig];
    return webView;
}

- (instancetype)initWithFrame:(CGRect)frame configuration:(WKWebViewConfiguration *)configuration {
    self = [super initWithFrame:frame configuration:configuration];
    if (self) {
        self.scrollView.bounces= false;
        self.navigationDelegate = self;
        self.scrollView.scrollEnabled = NO;
        self.opaque = YES;
        self.backgroundColor = [UIColor whiteColor];
        NSURL *fileUrl = [[NSBundle mainBundle]URLForResource:@"PAEcharts" withExtension:@"html"];
        self.eReauest = [NSMutableURLRequest requestWithURL:fileUrl];
        [self loadRequest:self.eReauest];
    }
    return self;
}

- (void)setCallJs:(NSString *)callJs {
    _callJs = callJs;
    !self.optionHandle ?: self.optionHandle();
}

- (void)clearEcharts {
    [self callJsMethods:@"myChart.clear()"];
}

- (void)showLoading:(NSDictionary *)loadingOption {
    [self callJsMethods:[NSString stringWithFormat:@"myChart.showLoading(%@)",[self.class getJSONString:loadingOption]]];
}

- (void)hideLoading {
    [self callJsMethods:@"myChart.hideLoading()"];
}

- (void)reloadOptions {
    [self callJsMethods:_callJs];
}

- (void)callJsMethods:(NSString *)methodWithParam {
    [self evaluateJavaScript:methodWithParam completionHandler:nil];
}

#pragma mark - WKScriptMessageHandler
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    __weak __typeof(self) weakSelf = self;
    [webView evaluateJavaScript:@"document.readyState" completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        if ([result isEqualToString:@"complete"]) {
            weakSelf.finishRender = YES;
            !weakSelf.finishComplete ?: weakSelf.finishComplete();
            if (weakSelf.callJs != nil) {
                [weakSelf callJsMethods:@"initEchartView()"];
                [weakSelf callJsMethods:weakSelf.callJs];
                [weakSelf reloadOptions];
            }
            
            CGFloat WB_HEIGHT = CGRectGetHeight(self.bounds);
            weakSelf.optionHandle = ^{
                [weakSelf clearEcharts];
                [weakSelf reloadOptions];
                if (WB_HEIGHT != CGRectGetHeight(self.bounds)) {
                    [weakSelf callJsMethods:@"onresize()"];
                }
            };
            
        }  else {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (!weakSelf.finishRender) {
                    [weakSelf loadRequest:weakSelf.eReauest];
                }
            });
        } 
    }];
}

- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    if ([message.name isEqualToString: @"share"]) {
        NSLog(@"%@",message.body);
    }
}

+ (NSString *)getJSONString:(id)obj {
    if([obj isKindOfClass:NSString.class]){
        return  [NSString stringWithFormat:@"\"%@\"",obj];
    }
    
    NSError *error;
    NSString *jsonString;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:&error];
    if (!jsonData) {
        NSLog(@"%@",error);
    }else{
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];
    NSRange range = {0,jsonString.length};
    //去掉字符串中的空格
    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];
    NSRange range2 = {0,mutStr.length};
    //去掉字符串中的换行符
    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    return mutStr;
}

@end





