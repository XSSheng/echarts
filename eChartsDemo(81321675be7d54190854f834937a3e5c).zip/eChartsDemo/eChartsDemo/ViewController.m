//
//  ViewController.m
//  eChartsDemo
//
//  Created by 徐胜(平安城科) on 2019/10/15.
//  Copyright © 2019 徐胜(平安城科). All rights reserved.
//

#import "ViewController.h"
#import "PAEchartsView.h"

@interface TableViewCell : UITableViewCell
@property (nonatomic,strong)PAEchartsView *echartsView;
@end
@implementation TableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.echartsView = [PAEchartsView newWithFrame:CGRectMake(0, 0, 400, 300)];
        [self.contentView addSubview:self.echartsView];
    }
    return self;
}
@end

@interface ViewController () <UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, copy)NSArray *resultList;
@property (nonatomic, weak)UITableView *tableView;

@end

@implementation ViewController

- (UITableView *)tableView {
    if (_tableView == nil) {
        UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        [tableView registerClass:TableViewCell.class forCellReuseIdentifier:NSStringFromClass(TableViewCell.class)];
        tableView.delegate = self;
        tableView.dataSource = self;
        return _tableView = tableView;
    }
    return _tableView;
}
//https://www.echartsjs.com 参考样式
-(NSArray *)resultList {
    if(_resultList == nil) {
        NSDictionary *obj1 = @{@"callJs":@"echartsFun1()"};
        NSDictionary *obj2 = @{@"callJs":@"echartsFun2()"};
        NSDictionary *obj3 = @{@"callJs":@"echartsFun3()"};
        NSDictionary *obj4 = @{@"callJs":@"echartsFun4()"};
        NSDictionary *obj5 = @{@"callJs":@"echartsFun5()"};
        NSDictionary *obj6 = @{@"callJs":@"echartsFun6()"};
        NSDictionary *obj7 = @{@"callJs":@"echartsFun7()"};
        _resultList = @[obj1,obj2,obj3,obj4,obj5,obj6,obj7];
    }
    return _resultList;
};

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.resultList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(TableViewCell.class) forIndexPath:indexPath];
    NSDictionary *item = self.resultList[indexPath.row];
    [cell.echartsView setCallJs:item[@"callJs"]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 300;
}

@end


